Global MFE Prediction
=====================

Variations of the global Minimum Free Energy (MFE) prediction algorithm.

We provide implementations of the global MFE prediction algorithm for

* Single sequences,
* Multiple sequence alignments (MSA), and
* RNA-RNA hybrids

API Symbols
-----------

.. doxygengroup:: mfe_global
  :no-title:
