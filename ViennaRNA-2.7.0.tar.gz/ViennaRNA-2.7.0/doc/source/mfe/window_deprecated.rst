Deprecated Interface for Local (sliding window) MFE Prediction
==============================================================

.. doxygengroup:: mfe_window_deprecated
    :no-title:
