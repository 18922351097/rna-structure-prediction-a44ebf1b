Deprecated Interface for Global MFE Prediction
==============================================

.. doxygengroup:: mfe_global_deprecated
    :no-title:
