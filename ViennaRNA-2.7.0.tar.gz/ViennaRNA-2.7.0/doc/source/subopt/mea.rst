Compute the Structure with Maximum Expected Accuracy (MEA)
==========================================================

.. doxygengroup:: mea_fold
    :no-title:
