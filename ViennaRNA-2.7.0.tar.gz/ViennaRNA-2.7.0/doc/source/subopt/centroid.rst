Compute the Centroid Structure
==============================

.. doxygengroup:: centroid_fold
    :no-title:
