Random Structure Samples from the Ensemble
==========================================

.. doxygengroup:: subopt_stochbt
    :no-title:

Deprecated API
--------------

.. doxygengroup:: subopt_stochbt_deprecated
    :no-title:
