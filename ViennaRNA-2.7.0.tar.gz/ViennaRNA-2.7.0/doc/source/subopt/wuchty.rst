Suboptimal Structures within an Energy Band around the MFE
==========================================================

.. doxygengroup:: subopt_wuchty
    :no-title:
