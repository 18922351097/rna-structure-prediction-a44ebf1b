Utilities
=========

.. toctree::
   :maxdepth: 1
   :caption: Specialized Modules:

   utils/alphabet
   utils/strings
   utils/structures
   utils/msa
   utils/io
   utils/plots
   utils/search
   utils/combinatorics
   utils/data_structures
   utils/messages
   utils/logs
   utils/units

.. doxygengroup:: utils
    :no-title:
