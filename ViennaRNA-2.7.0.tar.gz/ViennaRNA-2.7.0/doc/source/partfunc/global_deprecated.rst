Deprecated Interface for Global Partition Function Computation
==============================================================

.. doxygengroup:: part_func_global_deprecated
    :no-title:
