Generate Soft Constraints from Data
===================================

Find a vector of perturbation energies that minimizes the discripancies between
predicted and observed pairing probabilities and the amount of neccessary adjustments.

.. doxygengroup:: perturbation
    :no-title:
