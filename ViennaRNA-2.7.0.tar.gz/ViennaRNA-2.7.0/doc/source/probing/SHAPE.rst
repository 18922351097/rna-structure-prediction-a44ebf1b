SHAPE Reactivity Data
=====================

Incorporate SHAPE reactivity structure probing data into the folding
recursions by means of soft constraints.

Details for our implementation to incorporate SHAPE reactivity data to guide
secondary structure prediction can be found in :cite:t:`lorenz:2016a`.

.. doxygengroup:: SHAPE_reactivities
    :no-title:
