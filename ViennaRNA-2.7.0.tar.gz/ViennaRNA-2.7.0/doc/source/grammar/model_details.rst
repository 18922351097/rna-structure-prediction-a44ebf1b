Fine-tuning of the Implemented Models
=====================================

Functions and data structures to fine-tune the implemented
secondary structure evaluation model.

.. doxygengroup:: model_details
    :no-title:
