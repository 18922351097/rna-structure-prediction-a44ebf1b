# License

```{include} ../../license.txt
```
