Direct Refolding Paths between two Secondary Structures
=======================================================


Heuristics to explore direct, optimal (re-)folding paths between
two secondary structures.

.. doxygengroup:: paths_direct
    :no-title:
