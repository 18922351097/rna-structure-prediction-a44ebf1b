Folding Paths that start at a single Secondary Structure
========================================================

Implementation of gradient- and random walks starting from
a single secondary structure.

.. doxygengroup:: paths_walk
    :no-title:
