Deprecated Interface for (Re-)folding Paths, Saddle Points, and Energy Barriers
===============================================================================

.. doxygengroup:: paths_deprecated
    :no-title:
