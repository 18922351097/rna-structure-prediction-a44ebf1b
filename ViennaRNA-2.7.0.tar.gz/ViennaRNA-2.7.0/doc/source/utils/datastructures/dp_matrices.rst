The Dynamic Programming Matrices
================================

.. doxygengroup:: dp_matrices
    :no-title:
