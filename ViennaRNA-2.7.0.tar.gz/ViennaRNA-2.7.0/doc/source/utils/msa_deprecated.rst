Deprecated Interface for Multiple Sequence Alignment Utilities
==============================================================

.. doxygengroup:: aln_utils_deprecated
    :no-title:
