Annotation
==========

Functions to generate annotations for secondary structure
plots, dot-plots, and others.

.. doxygengroup:: annotation_utils
    :no-title:
