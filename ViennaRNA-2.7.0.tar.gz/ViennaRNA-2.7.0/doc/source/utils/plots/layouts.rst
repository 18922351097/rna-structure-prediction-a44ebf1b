Layouts and Coordinates
=======================

Functions to compute coordinate layouts for secondary structure plots.

.. doxygengroup:: plot_layout_utils
    :no-title:
