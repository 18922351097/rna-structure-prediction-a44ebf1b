Alignment Plots
===============

Functions to generate Alignment plots with annotated consensus structure.

.. doxygengroup:: alignment_plots
    :no-title:
