Pair Probability Plots
======================

Functions related to plotting of probabilities, such as dot-plots.

.. doxygengroup:: plot_probabilities
    :no-title:
