Tree Representation of Secondary Structures
===========================================

.. doxygengroup:: struct_utils_tree
    :no-title:
