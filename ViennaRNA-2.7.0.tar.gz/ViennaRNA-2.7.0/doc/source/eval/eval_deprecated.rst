Deprecated Interface for Free Energy Evaluation
===============================================

Using the functions below is discouraged as they have been marked
deprecated and will be removed from the library in the (near) future!

.. toctree::
   :maxdepth: 1
   :caption: Contents:

.. doxygengroup:: eval_deprecated
    :no-title:
