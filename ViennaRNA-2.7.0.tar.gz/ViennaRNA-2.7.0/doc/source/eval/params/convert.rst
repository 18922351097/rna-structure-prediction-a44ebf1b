Converting Energy Parameter Files
=================================

Converting energy parameter files into the latest format.

To preserve some backward compatibility the RNAlib also provides
functions to convert energy parameter files from the format used
in version 1.4-1.8 into the new format used since version 2.0

.. doxygengroup:: energy_parameters_convert
    :no-title:

