
Class Warnings
==============

Test 'cannot find project' warning.

.. doxygenclass:: MyClass
   :project: nonexistent


Test 'cannot find xml' warning:

.. doxygenclass:: MyClass
   :project: invalidproject


Test 'cannot find class' warning:

.. doxygenclass:: NonExistentClass
   :project: class


