
Embedded ReStructuredText
=========================

.. cpp:namespace:: @ex_embedded_rst

.. doxygenindex:: 
   :path: ../../examples/specific/rst/xml

