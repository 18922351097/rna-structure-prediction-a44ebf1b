/** A Test5 class.
 *  More details about this class.
 */

class Test5
{
  public:
    /** An example member function.
     *  More details about this function.
     */
    void example();
};

void Test5::example() {}

/** \example example_test.cpp
 * This is an example of how to use the Test5 class.
 * More details about this example.
 */
