
union Union {
	int i;
};

struct Class {
	union Union {
		int i;
	};
};
