/*! More detailed description

    Yeah and some more.
*/
int open_di(const char * pathname, int flags) {
	return 0;
}

namespace testnamespace {

/*! Even more documentation. */
int another_open_di(const char *,int)
{
	return 0;
}

}
