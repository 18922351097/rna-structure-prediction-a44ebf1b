
struct ACStruct {
	int i;

	struct ANestedStruct {
		int i;
	};
};

