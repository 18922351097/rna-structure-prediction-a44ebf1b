/**
 * @file
 */

/// Base class
class Base
{
public:
    /// Base-class member function
    void f_issue_356();
};

/// Class A
class A : public Base {};
/// Class B
class B : public Base {};
